package com.cg.hbms.entities;

public class Hotel {
	private Integer hotelId;
	private String city;
	private String hotelName;
	private String address;
	private String description;
	private Double avgRatePerNight;
	private String phoneNoOne;
	private String phoneNoTwo;
	private String rating;
	private String email;
	private String fax;
	
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getAvgRatePerNight() {
		return avgRatePerNight;
	}
	public void setAvgRatePerNight(Double avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}
	public String getPhoneNoOne() {
		return phoneNoOne;
	}
	public void setPhoneNoOne(String phoneNoOne) {
		this.phoneNoOne = phoneNoOne;
	}
	public String getPhoneNoTwo() {
		return phoneNoTwo;
	}
	public void setPhoneNoTwo(String phoneNoTwo) {
		this.phoneNoTwo = phoneNoTwo;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", avgRatePerNight=" + avgRatePerNight
				+ ", phoneNoOne=" + phoneNoOne + ", phoneNoTwo=" + phoneNoTwo
				+ ", rating=" + rating + ", email=" + email + ", fax=" + fax
				+ "]";
	}
	
	
}
