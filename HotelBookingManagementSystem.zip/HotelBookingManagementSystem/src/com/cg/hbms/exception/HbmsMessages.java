package com.cg.hbms.exception;

public class HbmsMessages {
	
	public static final String NO_USER = "No user found in database";
	public static final String USER_EXIST = "User already exist";

}
