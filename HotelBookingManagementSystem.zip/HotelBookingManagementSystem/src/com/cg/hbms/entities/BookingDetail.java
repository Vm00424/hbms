package com.cg.hbms.entities;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.transaction.Transactional;

import org.hibernate.validator.constraints.NotEmpty;

/*CREATE TABLE BOOKINGDETAILS(booking_id VARCHAR2(4) PRIMARY KEY,
		room_id VARCHAR2(4),
		user_id VARCHAR2(4),
		booked_from DATE,
		booked_to DATE,
		no_of_adults NUMBER,
		no_of_children NUMBER,
		amount NUMBER(6,2),
		CONSTRAINT fk_room_user FOREIGN KEY(room_id) REFERENCES ROOMDETAILS(room_id),FOREIGN KEY(user_id) REFERENCES USERS(user_id)
		ON DELETE CASCADE);*/
@Entity
@Table(name="bookingDetails")
public class BookingDetail {

private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="booking_detail_seq")
	@SequenceGenerator(name="booking_detail_seq",sequenceName="booking_detail_seq",allocationSize=10)
	@Column (name="booking_id")
	private int bookingId;
	
	@Column(name="booked_from")
	private Date bookedFrom;
	
	@Column(name="booked_to")
	private Date bookedTo;
	
	@Column(name="no_of_adults")
	private int noOfAdults;
	
	@Column(name="no_of_children")
	private int noOfChildren;
	
	@Column(name="amount1")
	private double amount1;
	
	public double getAmount1() {
		return amount1;
	}

	public void setAmount1(double amount1) {
		this.amount1 = amount1;
	}

	public double getAmount2() {
		return amount2;
	}

	public void setAmount2(double amount2) {
		this.amount2 = amount2;
	}

	@Column(name="amount2")
	private double amount2;

	@Column(name="hotel_name")
    private String hotelName;	

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	



	public Date getBookedFrom() {
		return bookedFrom;
	}

	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}

	public Date getBookedTo() {
		return bookedTo;
	}

	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public BookingDetail() {
	}

	
}
