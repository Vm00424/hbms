package com.cg.hbms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbms.dao.IHbmsDao;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

@Service
public class HbmsServiceImpl implements IHbmsService {

	@Autowired
	private IHbmsDao hbmsDao;
	
	@Override
	public User registerUser(User user) throws HbmsException {
		return hbmsDao.registerUser(user);
	}

	@Override
	public User loginUser(User user) throws HbmsException {
		return hbmsDao.loginUser(user);
	}

	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		return hbmsDao.getHotelList();
	}

}
