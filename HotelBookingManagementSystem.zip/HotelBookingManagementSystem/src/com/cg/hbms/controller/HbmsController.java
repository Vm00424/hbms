package com.cg.hbms.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.IHbmsService;


@Controller
public class HbmsController {
	
	@Autowired 
	private IHbmsService hbmsService;
	
	@RequestMapping("/index.obj")
	public String goHome(Model model){
		return "index";
	}
	
	@RequestMapping("/login.obj")
	public String goToLogin(Model model){
		model.addAttribute("user", new User());
		return "login";
	}
	
	@RequestMapping("/loginNow.obj")
	public ModelAndView goToDashboard(@ModelAttribute("user") User user) throws HbmsException{
		ModelAndView model = new ModelAndView();
		
		User currUser = hbmsService.loginUser(user);
		if(currUser != null && currUser.getRole().equals("admin")){
			
			model.setViewName("dashAdmin");
		}else if(currUser != null){
			model.setViewName("dash");
		}
		model.addObject("user", currUser);
		return model;
	}
	
	@RequestMapping("/register.obj")
	public String goToRegister(Model model){
		model.addAttribute("user", new User());
		return "register";
	}
	
	
	@RequestMapping("/registerNow.obj")
	public ModelAndView registerNow(@ModelAttribute("user") @Valid User user, BindingResult bindingResult) throws HbmsException{
		ModelAndView model = new ModelAndView();
		
		if(bindingResult.hasErrors()){
			model.setViewName("error");
		}
		
		
		User user1 = hbmsService.registerUser(user);
		model.addObject("user", user1);
		
		return model;
	}
	
	@RequestMapping("/searchHotel.obj")
	public String showHotels(Model model) throws HbmsException {
		System.out.println("1");
		List<Hotel> hotelList = hbmsService.getHotelList();
		
		Iterator<Hotel> itr = hotelList.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		model.addAttribute("hotelList", hotelList);
		
		return "showHotels";
	}
	

}
