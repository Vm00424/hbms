package com.cg.hbms.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.exception.HbmsMessages;
import com.cg.hbms.service.IHbmsService;


@Controller
public class HbmsController {
	
	@Autowired 
	private IHbmsService hbmsService;
	static User userScope;
	static Hotel hotelToken;
	
	
	@RequestMapping("/index.obj")
	public String goHome(Model model){
		return "index";
	}

	@RequestMapping("/login.obj")
	public String goToLogin(Model model){
		model.addAttribute("user", new User());
		model.addAttribute("message", null);
		return "login";
	}
	
	@RequestMapping("/logout.obj")
	public String goToLogout(Model model){
		userScope = null;
		return "index";
	}
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/loginNow.obj")
	public ModelAndView goToDashboard(@ModelAttribute("user") User user) throws HbmsException{
		ModelAndView model = new ModelAndView();

		User currUser = hbmsService.loginUser(user);
		if(currUser != null && currUser.getRole().equals("admin")){
			userScope = currUser;
			model.setViewName("admin_dash");
		}
		else if(currUser != null){
			userScope = currUser;
			model.setViewName("user_dash");
			model.addObject("user", currUser);
		}
		else{
			model.setViewName("login");
			model.addObject("user", new User());
			model.addObject("message", HbmsMessages.NO_USER);
			return model;
		}
		model.addObject("user", currUser);
		return model;
	}




	@RequestMapping("/register.obj")
	public String goToRegister(Model model){
		model.addAttribute("user", new User());
		model.addAttribute("message", null);
		return "register";
	}
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/registerNow.obj")
	public ModelAndView registerNow(@ModelAttribute("user") @Valid User user, BindingResult bindingResult) throws HbmsException{
		ModelAndView model = new ModelAndView();
		
		if(bindingResult.hasErrors()){
			model.setViewName("error");
			return model;
		}


		User user1 = hbmsService.registerUser(user);
		model.setViewName("register");
		model.addObject("user", new User());
		if(user1 == null)
			model.addObject("message", HbmsMessages.USER_EXIST);
		else
			model.addObject("message", HbmsMessages.REGISTERED);

		return model;
	}




	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/searchHotel.obj")
	public String showHotels(Model model) throws HbmsException {
		List<Hotel> hotelList = hbmsService.getHotelList();
		if(hotelList == null){
			model.addAttribute("message", HbmsMessages.NO_HOTEL);
			model.addAttribute("hotelList", null);
		}
		else{

			model.addAttribute("message", null);
			model.addAttribute("hotelList", hotelList);
		}
		return "user_hotels";
	}

	
	
	
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/viewBookings.obj")
	public String showBookings(Model model) throws HbmsException {
		List<BookingDetail> bookingList = hbmsService.getBookingList(userScope);
		if(bookingList == null){
			model.addAttribute("message", HbmsMessages.NO_BOOKING);
			model.addAttribute("bookingList", null);
		}
		else{

			model.addAttribute("message", null);
			model.addAttribute("bookingList", bookingList);
		}
		return "user_bookings";
	}
	
	
	
	
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/hotelMgmt.obj")
	public String hotelManagement(Model model) throws HbmsException{
		List<Hotel> hotelList = hbmsService.getHotelList();
		if(hotelList == null){
			model.addAttribute("message", HbmsMessages.NO_HOTEL);
			model.addAttribute("hotelList", null);
		}
		else{

			model.addAttribute("message", null);
			model.addAttribute("hotelList", hotelList);
		}
		return "admin_hotels";
	}
	
//FORWARD TO HOTEL DETAILS INPUT PAGE
	@RequestMapping("/addHotel.obj")
	public String addHotel(Model model){
		model.addAttribute("hotel", new Hotel());
		model.addAttribute("message", null);
		return "hotel_add";
	}
	
//ADD HOTEL TO DATABASE	
	@RequestMapping("/addHotelNow.obj")
	public String addHotelNow(@ModelAttribute("hotel") Hotel hotel,Model model) throws HbmsException{
		Hotel currHotel = hbmsService.addHotel(hotel);
		model.addAttribute("message", HbmsMessages.HOTEL_ADDED+", Hotel ID: "+currHotel.getHotelId());
		model.addAttribute("hotel",new Hotel());
		return "hotel_add";
	}
	
//DELETE HOTEL FROM DATABASE AND FORWARD TO HOTEL DETAILS
	@RequestMapping("/deleteHotel.obj")
	public String deleteHotel(@RequestParam("hotelId") Integer hotelId,Model model) throws HbmsException{
		System.out.println("hotel : "+hotelId);
		String result = hbmsService.deleteHotel(hotelId);
		if(result.equals("1"))
			model.addAttribute("message", HbmsMessages.HOTEL_DELETED);
		else
			model.addAttribute("message", HbmsMessages.ERROR);
		
		List<Hotel> hotelList = hbmsService.getHotelList();
		if(hotelList == null){
			model.addAttribute("hotelList", null);
		}
		else{
			model.addAttribute("hotelList", hotelList);
		}
		return "admin_hotels";
	}
	
//FORWARD TO HOTEL MODIFICATION PAGE
	@RequestMapping("/modifyHotel.obj")
	public String modifyHotel(@RequestParam("hotelId") Integer hotelId,Model model) throws HbmsException{
		Hotel hotel = hbmsService.getHotel(hotelId);
		model.addAttribute("hotel", hotel);
		//hotelToken.setHotelId(hotelId);
		return "hotel_modify";
	}
	
//UPDATE DETAILS OF HOTEL AND FORWARD TO HOTEL DETAILS PAGE
	@RequestMapping("/modifyHotelNow.obj")
	public String modifyHotelNow(@ModelAttribute("hotel") Hotel hotel,Model model) throws HbmsException{
		Hotel updatedHotel;
		//System.out.println("id: "+hotel.getHotelId());
		updatedHotel = hbmsService.modifyHotel(hotel);
		
		if(updatedHotel == null){
			model.addAttribute("message", HbmsMessages.HOTEL_NOT_EXIST);
		}else{
			//hotel = hbmsService.modifyHotel(hotel);
			model.addAttribute("message", HbmsMessages.HOTEL_MODIFIED);
		}
		
		
		List<Hotel> hotelList = hbmsService.getHotelList();
		if(hotelList == null){
			model.addAttribute("hotelList", null);
		}
		else{
			model.addAttribute("hotelList", hotelList);
		}
		return "admin_hotels";
	}
	
	
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/roomMgmt.obj")
	public String roomManagement(Model model) throws HbmsException{
		List<RoomDetail> roomList = hbmsService.getRoomList();
		if(roomList == null){
			model.addAttribute("message", HbmsMessages.ROOM_NOT_EXIST);
			model.addAttribute("roomList", null);
		}
		else{

			model.addAttribute("message", null);
			model.addAttribute("roomList", roomList);
		}
		return "admin_rooms";
	}
	
//FORWARD TO ROOM DETAILS INPUT PAGE
	@RequestMapping("/addRoom.obj")
	public String addRoom(Model model) throws HbmsException{
		
		model.addAttribute("room", new RoomDetail());
		List<Hotel> hotelList = hbmsService.getHotelList();
		List<Integer> idList = new ArrayList<Integer>();

		if(hotelList == null){
			model.addAttribute("message", "No Hotel Available");
		}
		else{
			Iterator<Hotel> itr = hotelList.iterator();
			while(itr.hasNext()){
				idList.add(itr.next().getHotelId());
			}
		}
		model.addAttribute("idList", idList);
		model.addAttribute("message", null);
		return "room_add";
	}
	
//ADD ROOM TO DATABASE	
	@RequestMapping("/addRoomNow.obj")
	public String addRoomNow(@RequestParam("photo") String photo, @ModelAttribute("room") RoomDetail room,Model model) throws HbmsException{
		System.out.println("photo path: "+photo);
		room.setPhoto(new File(photo));
		RoomDetail currRoom = hbmsService.addRoom(room);
		model.addAttribute("message", HbmsMessages.ROOM_ADDED+", Room ID: "+currRoom.getRoomId());
		model.addAttribute("room",new RoomDetail());
		return "room_add";
	}
	
//DELETE ROOM FROM DATABASE AND FORWARD TO ROOM DETAILS
	@RequestMapping("/deleteRoom.obj")
	public String deleteRoom(@RequestParam("roomId") Integer roomId,Model model) throws HbmsException{
		System.out.println("room : "+roomId);
		String result = hbmsService.deleteRoom(roomId);
		if(result.equals("1"))
			model.addAttribute("message", HbmsMessages.ROOM_DELETED);
		else
			model.addAttribute("message", HbmsMessages.ERROR);
		
		List<RoomDetail> roomList = hbmsService.getRoomList();
		if(roomList == null){
			model.addAttribute("roomList", null);
		}
		else{
			model.addAttribute("roomList", roomList);
		}
		return "admin_rooms";
	}
	
//FORWARD TO ROOM MODIFICATION PAGE
	@RequestMapping("/modifyRoom.obj")
	public String modifyRoom(@RequestParam("roomId") Integer roomId,Model model) throws HbmsException{
		RoomDetail room = hbmsService.getRoom(roomId);
		model.addAttribute("room", room);
		return "room_modify";
	}
	
//UPDATE DETAILS OF ROOM AND FORWARD TO HOTEL DETAILS PAGE
	@RequestMapping("/modifyRoomNow.obj")
	public String modifyRoomNow(@ModelAttribute("room") RoomDetail room,Model model) throws HbmsException{
		RoomDetail updatedRoom;
		
		if(room == null){
			model.addAttribute("message", HbmsMessages.ROOM_NOT_EXIST);
		}else{
			updatedRoom = hbmsService.modifyRoom(room);
			model.addAttribute("message", HbmsMessages.ROOM_MODIFIED);
		}
		
		
		List<RoomDetail> roomList = hbmsService.getRoomList();
		if(roomList == null){
			model.addAttribute("roomList", null);
		}
		else{
			model.addAttribute("roomList", roomList);
		}
		return "admin_rooms";
	}
	
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/report.obj")
	public String goToReport(){
		return "report_index";
	}
	
	@RequestMapping("/viewAllHotelsReport.obj")
	public String hotelReports(Model model) throws HbmsException{
		List<Hotel> hotelList= hbmsService.getHotelList();
		if(hotelList==null){
			model.addAttribute("message", HbmsMessages.HOTEL_NOT_EXIST);
		}else{
			model.addAttribute("message", null);
		}
		model.addAttribute("hotelList", hotelList);
		return "report_hotels";
	}
	
	@RequestMapping("/viewBookingHotelReport.obj")
	public String viewBookReport(Model model) throws HbmsException{
		List<Hotel> hotelList = hbmsService.getHotelList();
		List<Integer> idList = new ArrayList<Integer>();

		if(hotelList == null){
			model.addAttribute("message",HbmsMessages.HOTEL_NOT_EXIST);
		}
		else{
			Iterator<Hotel> itr = hotelList.iterator();
			while(itr.hasNext()){
				idList.add(itr.next().getHotelId());
			}
		}
		model.addAttribute("hotel", new Hotel());
		model.addAttribute("idList", idList);
		model.addAttribute("message", null);
		return "report_select_hotel";
	}
	

	@RequestMapping("/viewBookingHotelNow.obj")
	public String viewBookingHotelNow(@ModelAttribute("hotel") Hotel hotel, Model model) throws HbmsException{
		List<BookingDetail> bookingList=hbmsService.getBookingDetails(hotel);
		if(bookingList==null){
			model.addAttribute("message", HbmsMessages.NO_BOOKING);
		}else{
			model.addAttribute("message", null);
		}
		model.addAttribute("bookingList", bookingList);
		return "report_bookings_by_hotel";
	}
	
	@RequestMapping("/viewGuestListReport.obj")
	public String viewGuestList(Model model) throws HbmsException{
		List<Hotel> hotelList = hbmsService.getHotelList();
		List<Integer> idList = new ArrayList<Integer>();

		if(hotelList == null){
			model.addAttribute("message",HbmsMessages.HOTEL_NOT_EXIST);
		}
		else{
			Iterator<Hotel> itr = hotelList.iterator();
			while(itr.hasNext()){
				idList.add(itr.next().getHotelId());
			}
		}
		model.addAttribute("hotel", new Hotel());
		model.addAttribute("idList", idList);
		model.addAttribute("message", null);
		return "report_select_hotel";
	}
	
	@RequestMapping("/viewBookingGuestNow.obj")
	public String viewBookingGuestNow(@ModelAttribute("hotel") Hotel hotel, Model model) throws HbmsException{
		List<BookingDetail> bookingList=hbmsService.getBookingDetails(hotel);
		if(bookingList==null){
			model.addAttribute("message", HbmsMessages.NO_BOOKING);
		}else{
			model.addAttribute("message", null);
		}
		model.addAttribute("bookingList", bookingList);
		return "report_guest_by_hotel";
	}
	/***************************************************************************************
	 * Function :		
	 * Parameter :		
	 * Return type :	
	 * Date :			04/09/2018
	 * Description :	
	 *****************************************************************************************/
	@RequestMapping("/bookHotel.obj")
	public String bookHotel(@RequestParam("hotelId") Integer hotelId,Model model) throws HbmsException{
		List<RoomDetail> roomList = hbmsService.getRoomList();
		if(roomList == null){
			model.addAttribute("message", HbmsMessages.ROOM_NOT_EXIST);
		}
		else{
			model.addAttribute("message", null);
		}
		model.addAttribute("roomList", roomList);
		return "user_book_hotel";
	}
	
	
	@RequestMapping("/bookRoom")
	public String bookRoom(@RequestParam("roomId") Integer roomId,Model model) throws HbmsException{
		RoomDetail room = hbmsService.getRoom(roomId);
		model.addAttribute("room", room);
		model.addAttribute("booking", new BookingDetail());
		return "user_book_room";
	}
	
	
	@RequestMapping("/bookRoomNow.obj")
	public String bookRoomNow(@ModelAttribute("booking") BookingDetail booking,@RequestParam("roomId") Integer roomId, Model model) throws HbmsException{
		booking.setRoomId(roomId);
		booking.setUserId(userScope.getUserId());
		
		BookingDetail currBooking = hbmsService.addBooking(booking);
		model.addAttribute("message", HbmsMessages.ROOM_ADDED+", Booking ID: "+currBooking.getBookingId());
		return showHotels(model);
		//return "user_hotels";
	}
}
