package com.cg.hbms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

@Repository
@Transactional
public class HbmsDaoImpl implements IHbmsDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public User registerUser(User user) throws HbmsException {
		entityManager.persist(user);
		//entityManager.flush();
		return user;
	}


	@Override
	public User loginUser(User user) throws HbmsException {
		TypedQuery<User> query = entityManager.createQuery("SELECT u FROM User u WHERE u.userName=? AND u.password=?",User.class);
		query.setParameter(1, user.getUserName());
		query.setParameter(2, user.getPassword());
		User userDetails = query.getSingleResult();
		return userDetails;
	}
	
}
