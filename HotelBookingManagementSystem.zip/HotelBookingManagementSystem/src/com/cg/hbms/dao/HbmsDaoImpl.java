package com.cg.hbms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

@Repository
@Transactional
public class HbmsDaoImpl implements IHbmsDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public User registerUser(User user) throws HbmsException {
		if(findUser(user.getUserName()) == 0){
			entityManager.persist(user);
			entityManager.flush();
			return user;
		}
		return null;
	}


	@Override
	public User loginUser(User user) throws HbmsException {
		TypedQuery<User> query = entityManager.createQuery("SELECT u FROM User u WHERE u.userName=? AND u.password=?",User.class);
		query.setParameter(1, user.getUserName());
		query.setParameter(2, user.getPassword());
		User userDetails = query.getSingleResult();
		return userDetails;
	}
	
	public int findUser(String userName) throws HbmsException {
		TypedQuery<User> query = entityManager.createQuery("SELECT u FROM User u WHERE u.userName=?",User.class);
		query.setParameter(1, userName);
		List<User> list = query.getResultList();
		if(list.isEmpty()){
			return 0;
		}
		return 1;
	}


	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		TypedQuery<Hotel> query = entityManager.createQuery("SELECT h FROM Hotel h", Hotel.class);
		List<Hotel> hotelList = query.getResultList();
		if(hotelList.isEmpty())
			return null;
		
		return hotelList;
	}
	
}
