package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public interface IHbmsDao {
	
	public User registerUser(User user) throws HbmsException;
	public User loginUser(User user) throws HbmsException;
	
	public List<Hotel> getHotelList() throws HbmsException;
	
}
