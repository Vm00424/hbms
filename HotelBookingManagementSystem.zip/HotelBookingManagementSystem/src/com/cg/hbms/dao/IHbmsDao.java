package com.cg.hbms.dao;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public interface IHbmsDao {
	
	public User registerUser(User user) throws HbmsException;
	public User loginUser(User user) throws HbmsException;
	
}
