package com.cg.hbms.client;

import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IHbmsService;
import com.cg.hbms.service.IUserService;
import com.cg.hbms.service.UserServiceImpl;

public class HbmsMain {
	static User user;
	static Scanner scanner;
	static IUserService userService;
	
	public static void main(String[] args) throws HbmsException {
		
		HbmsMain main = new HbmsMain();
		IHbmsService hbmsService = new HbmsServiceImpl();
		boolean isTrue = true;
		String choiceIndex = "-1";
		
		scanner = new Scanner(new InputStreamReader(System.in));
		user = new User();
		
		while(isTrue) {
			System.out.println("1. Login\n2. Register Now\n#. Exit\n");
			choiceIndex = scanner.next();
			
			
			
			switch (choiceIndex) {
			case "1":	main.getLoginDetails();
						user = hbmsService.loginUser(user);
				
						if(user == null) {
							System.out.println("Invalid Credentials !!! ");
						}else if(user.getRole().equals("admin")){
							main.gotoAdminDash();
						}else{
							main.gotoUserDash();
						}
						
				
				break;	

			case "2":	main.getRegisterationDetails();
						user = hbmsService.registerUser(user);
						
						if(user.getUserId() != null){
							System.out.println("registered successfully");
						}
				break;
				
			case "#":	isTrue = false;
			break;
			
			default:	System.out.println("Invalid Choice, Please try again.");
				break;
			}
			
			
			
		}
		

	}
	
	
	
	public void gotoAdminDash() {
		
	}
	
	
	public void gotoUserDash() throws HbmsException{
		
		userService = new UserServiceImpl();
		String choice="";
		boolean loggedIn = true;
		
		while(loggedIn){
			System.out.println("1. View Available Hotels\n2. View previous bookings\n*. Logout");
			choice = scanner.next();
			switch (choice) {
			case "1":	System.out.println("Available Hotels Are : ");
						List<Hotel> hotelList = userService.getHotelList();
						printList(hotelList);
				break;

			case "2":	System.out.println("Your Booking Details Are :");
						List<BookingDetail> bookingList = userService.getBookingByUser(user.getUserId());
						printList(bookingList);
				break;
				
			case "3":	List<Hotel> hotelList2 = userService.getHotelList();
						printList(hotelList2);
						System.out.println("Please Enter Hotel ID: ");
						String hotelId = scanner.next();
						System.out.println("Available Rooms Are: ");
						List<RoomDetail> roomList = userService.getRoomByHotel(Integer.parseInt(hotelId));
						printList(roomList);
						break;
					
			case "4":	System.out.println("");
				break;
				
			case "*":	System.out.println("Successfully Logged out, Please visit again.");
						loggedIn = false;
				break;
			default:	System.out.println("Invalid Choice, Please try again.");
				break;
			}
		
		}
		
	}
	
	
	public void getLoginDetails(){
		System.out.println("Please Enter Username:");
		user.setUserName(scanner.next());
		System.out.println("please Enter Password:");
		user.setPassword(scanner.next());
	}
	
	public void getRegisterationDetails() {
		getLoginDetails();
		System.out.println("Please Enter Role:");
		user.setRole(scanner.next());
		System.out.println("please Enter mobile No:");
		user.setMobileNumber(scanner.next());
		System.out.println("Please Enter phone:");
		user.setPhoneNumber(scanner.next());
		System.out.println("please Enter address:");
		user.setAddress(scanner.next());
		System.out.println("Please Enter email:");
		user.setEmail(scanner.next());
	}

	
	public void printList(List list) {
		Iterator iterator = list.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}
}
