package com.cg.hbms.client;

import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IAdminService;
import com.cg.hbms.service.IHbmsService;
import com.cg.hbms.service.IUserService;
import com.cg.hbms.service.UserServiceImpl;

public class HbmsMain {
	static User user;
	static Hotel hotel;
	static RoomDetail room;
	static BookingDetail booking;
	static Scanner scanner;
	static IUserService userService;
	static IHbmsService hbmsService;
	static IAdminService adminService;
	
	public static void main(String[] args) throws HbmsException {
		HbmsMain main = new HbmsMain();
		hbmsService = new HbmsServiceImpl();
		userService = new UserServiceImpl();
		user = new User();
		
		boolean isTrue = true;
		String choiceIndex = "-1";
		scanner = new Scanner(new InputStreamReader(System.in));
		
		while(isTrue) {
			System.out.println("1. Login\n2. Register Now\n#. Exit\n");
			choiceIndex = scanner.nextLine();
			
			switch (choiceIndex) {
			case "1":	main.login();
			break;	

			case "2":	main.register();
			break;
				
			case "#":	isTrue = false;
			break;
			
			default:	System.out.println("Invalid Choice, Please try again.");
				break;
			}
		}
	}
	
	
//#################################################################################################################//
	public void gotoAdminDash() throws HbmsException {
		adminService = new AdminServiceImpl();
		
		String choice = "";
		boolean loggedIn = true;
		
		while(loggedIn) {
			System.out.println("1. Hotel Management\n2. Room Management\n3. Generate reports\n*. Logout");
			choice = scanner.nextLine();
			switch (choice) {
			case "1":	manageHotel();
						break;

			case "2":	manageRoom();
						break;
				
			case "3":	generateReport();
						break;
					
			case "4":	bookRoom();
						break;
				
			case "*":	System.out.println("Successfully Logged out, Please visit again.");
						loggedIn = false;
						break;
						
			default:	System.out.println("Invalid Choice, Please try again.");
						break;
			}
		}
		
	}
	
	public void generateReport() throws HbmsException {
		
	}
	
	public void manageRoom() throws HbmsException {
		showRooms();
		System.out.println("1. Add Room\n2. Modify Room\n3. Delete Room");
		String choice = scanner.next();
		switch (choice) {
		case "1":	addRoom();
					break;

		case "2":	modifyRoom();
					break;
			
		case "3":	deleteRoom();
					break;
					
		default:	System.out.println("Invalid Choice, Please try again.");
					break;
		}
	}
	
	public void addRoom() throws HbmsException {
		getRoomDetails();
		adminService.addRoom(room);
	}

	public void modifyRoom() throws HbmsException {
		showHotels();
		getHotelDetails();
		adminService.modifyHotel(hotel);
	}

	public void deleteRoom() throws HbmsException {
		System.out.println("Enter hotel ID to delete hotel: ");
		String hotelId = scanner.next();
		adminService.deleteHotel(Integer.parseInt(hotelId));
	}
	
	public void showRooms() {
		
	}
	
	public void getRoomDetails(){
		
	}
	
	
	public void manageHotel() throws HbmsException {
		
		showHotels();
		hotel = new Hotel();
		System.out.println("1. Add Hotel\n2. Modify Hotel\n3. Delete Hotel");
		String choice = scanner.nextLine();
		switch (choice) {
		case "1":	addHotel();
					break;

		case "2":	modifyHotel();
					break;
			
		case "3":	deleteHotel();
					break;
					
		default:	System.out.println("Invalid Choice, Please try again.");
					break;
		}
	}
	
	public void addHotel() throws HbmsException {
		getHotelDetails();
		hotel = adminService.addHotel(hotel);
		
		if(hotel.getHotelId() != null)
			System.out.println("Hotel added successfully, hotel id is: "+hotel.getHotelId());
		else
			System.out.println("Something went wrong with the process, please try again.");
	}

	public void modifyHotel() throws HbmsException {
		showHotels();
		getHotelDetails();
		adminService.modifyHotel(hotel);
	}

	public void deleteHotel() throws HbmsException {
		System.out.println("Enter hotel ID to delete hotel: ");
		String hotelId = scanner.nextLine();
		Boolean result = adminService.deleteHotel(Integer.parseInt(hotelId));
		if(result)
			System.out.println("Hotel deleted Successfully.");
		else
			System.out.println("Something went wrong with the process, please try again.");
	}
	
	public void getHotelDetails() {
		System.out.println("Please Enter Hotel Details: ");
		System.out.print("Hotel Name: ");
		String hotelName = scanner.nextLine();
		System.out.print("City: ");
		String city = scanner.nextLine();
		System.out.print("Address: ");
		String address = scanner.nextLine();
		System.out.print("Description: ");
		String description = scanner.nextLine();
		System.out.print("Average Rate per Night: ");
		String ratePerNight = scanner.nextLine();
		System.out.print("Phone No. 1: ");
		String phoneOne = scanner.nextLine();
		System.out.print("Phone No 2: ");
		String phoneTwo = scanner.nextLine();
		System.out.print("Rating: ");
		String rating = scanner.nextLine();
		System.out.print("Email: ");
		String email = scanner.nextLine();
		System.out.print("Fax: ");
		String fax = scanner.nextLine();
		
		hotel.setHotelName(hotelName);
		hotel.setCity(city);
		hotel.setAddress(address);
		hotel.setDescription(description);
		hotel.setAvgRatePerNight(Double.parseDouble(ratePerNight));
		hotel.setPhoneNoOne(phoneOne);
		hotel.setPhoneNoTwo(phoneTwo);
		hotel.setRating(rating);
		hotel.setEmail(email);
		hotel.setFax(fax);
	}

//#####################################################################################################################//	
//###############################################################################################################//	
	public void gotoUserDash() throws HbmsException{
		
		String choice = "";
		boolean loggedIn = true;
		
		while(loggedIn){
			System.out.println("1. View Available Hotels\n2. View previous bookings\n3. View Rooms by hotel\n4. Book room\n*. Logout");
			choice = scanner.next();
			switch (choice) {
			case "1":	showHotels();
						break;

			case "2":	showBookings();
						break;
				
			case "3":	showRoomsByHotel();
						break;
					
			case "4":	bookRoom();
						break;
				
			case "*":	System.out.println("Successfully Logged out, Please visit again.");
						loggedIn = false;
						break;
						
			default:	System.out.println("Invalid Choice, Please try again.");
						break;
			}
		}
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void bookRoom() throws HbmsException {
		showRoomsByHotel();
		room = new RoomDetail();
		System.out.println("Please Enter Room ID: ");
		String roomId = scanner.next();
		System.out.println("Enter Check in Date(dd/mm/yyyy): ");
		String from = scanner.next();
		System.out.println("Enter Check out Date(dd/mm/yyyy): ");
		String to = scanner.next();
		System.out.println("Enter No of Adults: ");
		String noAdults = scanner.next();
		System.out.println("Enter No of Children: ");
		String noChildren = scanner.next();
		// validation  ///////////////////////////////////////////	
		Date bookedFrom = null;
		Date bookedTo = null;
		try {
			bookedFrom = new SimpleDateFormat("dd/MM/yyyy").parse(from);
			bookedTo = new SimpleDateFormat("dd/MM/yyyy").parse(to);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		room.setRoomId(Integer.parseInt(roomId));
		room = userService.getRoomById(room.getRoomId());
		booking.setRoomId(room.getRoomId());
		booking.setUserId(user.getUserId());
		booking.setBookedFrom(bookedFrom);
		booking.setBookedFrom(bookedTo);
		booking.setNoOfAdults(Integer.parseInt(noAdults));
		booking.setNoOfChildren(Integer.parseInt(noChildren));
		
		calculateAmount();
		booking = userService.bookRoom(booking);
		if(booking.getBookingId() != null) {
			System.out.println("Booking successful with Booking ID: "+booking.getBookingId()+" and Amount paid is: "+booking.getAmount());
		}else {
			System.out.println("Something went wrong with the process, please try again.");
		}
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void calculateAmount() {
		long diff = booking.getBookedFrom().getTime() - booking.getBookedTo().getTime();
		Long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		Double amount = days * room.getPerNightRate();
		booking.setAmount(amount);
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void showRoomsByHotel() throws HbmsException {
		showHotels();
		hotel = new Hotel();
		System.out.println("Please Enter Hotel ID: ");
		String hotelId = scanner.next();
		hotel.setHotelId(Integer.parseInt(hotelId));
		System.out.println("Available Rooms Are: ");
		List<RoomDetail> roomList = userService.getRoomByHotel(Integer.parseInt(hotelId));
		printList(roomList);
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void showHotels() throws HbmsException {
		System.out.println("Available Hotels Are : ");
		List<Hotel> hotelList = userService.getHotelList();
		printList(hotelList);
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void showBookings() throws HbmsException {
		System.out.println("Your Booking Details Are :");
		List<BookingDetail> bookingList = userService.getBookingByUser(user.getUserId());
		printList(bookingList);
	}
	
//#####################################################################################################################//
	public void register() throws HbmsException {
		getRegisterationDetails();
		user = hbmsService.registerUser(user);
		
		if(user.getUserId() != null){
			System.out.println("registered successfully");
		}
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void login() throws HbmsException {
		getLoginDetails();
		user = hbmsService.loginUser(user);

		if(user.getRole() == null) {
			System.out.println("Invalid Credentials !!! ");
		}else if(user.getRole().equals("admin")){
			gotoAdminDash();
		}else{
			gotoUserDash();
		}
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void getLoginDetails(){
		System.out.println("Please Enter Username:");
		user.setUserName(scanner.nextLine());
		System.out.println("please Enter Password:");
		user.setPassword(scanner.nextLine());
	}
	
///////////////////////////////////////////////////////////////////////////////////////
	public void getRegisterationDetails() {
		getLoginDetails();
		System.out.println("Please Enter Role:");
		user.setRole(scanner.nextLine());
		System.out.println("please Enter mobile No:");
		user.setMobileNumber(scanner.nextLine());
		System.out.println("Please Enter phone:");
		user.setPhoneNumber(scanner.nextLine());
		System.out.println("please Enter address:");
		user.setAddress(scanner.nextLine());
		System.out.println("Please Enter email:");
		user.setEmail(scanner.nextLine());
	}

///////////////////////////////////////////////////////////////////////////////////////
	public void printList(List list) {
		Iterator iterator = list.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}
}
