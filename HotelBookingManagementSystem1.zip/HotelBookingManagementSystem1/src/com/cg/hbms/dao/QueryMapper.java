package com.cg.hbms.dao;

public class QueryMapper {

	public static final String REGISTER_USER = "INSERT INTO users VALUES(user_id_seq.nextVal,?,?,?,?,?,?,?)";
	public static final String LOG_IN = "SELECT * FROM users WHERE user_name = ? AND password = ?";
	
	// Hotel Management
	
	public static final String ADD_HOTEL = "INSERT INTO hotel VALUES(hotel_id_seq.nextVal,?,?,?,?,?,?,?,?,?,?)";
	public static final String MODIFY_HOTEL = "ALTER TABLE hotel SET hotel_name=? , ?,?,?,?,?,?,?,?,?) WHERE hotel_id = ?";
	public static final String DELETE_HOTEL = "DELETE FROM hotel WHERE hotel_id = ?";
	
	
	
	// Room Management
	
	public static final String GET_ROOM = "SELECT * FROM roomDetails";
	public static final String ADD_ROOM = "INSERT INTO roomDetails VALUES(room_id_seq.nextVal,?,?,?,?,?)";
	public static final String MODIFY_ROOM = "";
	public static final String DELETE_ROOM = "DELETE FROM roomDetails WHERE room_id = ?";
	
	
	// Report generating queries
	
	public static final String GET_HOTEL = "SELECT * FROM hotel";
	public static final String GET_BOOKING_BY_HOTEL = "SELECT * FROM bookingDetails WHERE room_id IN (SELECT room_id FROM roomDetails WHERE hotel_id = ?)";
	public static final String GET_BOOKING_BY_DATE = "SELECT * FROM bookingDetails WHERE ? BEETWEEN booked_from AND booked_to";
	public static final String GET_USER_BY_HOTEL = "SELECT * FROM users WHERE user_id IN "
			+ "(SELECT user_id FROM bookingDetails WHERE room_id IN (SELECT room_id FROM roomDetails WHERE hotel_id = ?))";
	
	
	
	// USER function queries
	
	public static final String GET_BOOKING_BY_USER = "SELECT * FROM bookingDetails WHERE user_id = ?";
	public static final String GET_ROOM_BY_HOTEL = "SELECT * FROM roomDetails WHERE hotel_id = ?";
	public static final String GET_ROOM_BY_ID = "SELECT * FROM roomDetails WHERE room_id = ?";
	public static final String BOOK_ROOM = "INSERT INTO bookingDetails VALUES(booking_id_seq.nextVal,?,?,?,?,?,?,?)";
	public static final String GET_USER_BY_ID = "SELECT * FROM users WHERE user_id = ?";
	
	
	// Get Sequences
	public static final String GET_USER_CURR_SEQ = "SELECT user_id_seq.CURRVAL FROM DUAL";
	public static final String GET_HOTEL_CURR_SEQ = "SELECT hotel_id_seq.CURRVAL FROM DUAL";
	public static final String GET_ROOM_CURR_SEQ = "SELECT room_id_seq.CURRVAL FROM DUAL";
	public static final String GET_BOOKING_CURR_SEQ = "SELECT booking_id_seq.CURRVAL FROM DUAL";
	
	// Sequences
	/*
		Users = CREATE SEQUENCE user_id_seq START WITH 1000 INCREMENT BY 1;
		Hotel = CREATE SEQUENCE hotel_id_seq START WITH 1000 INCREMENT BY 1;
		RoomDetails = CREATE SEQUENCE room_id_seq START WITH 1000 INCREMENT BY 1;
		BookingDetails = CREATE SEQUENCE booking_id_seq START WITH 1000 INCREMENT BY 1;
		
	*/
}
