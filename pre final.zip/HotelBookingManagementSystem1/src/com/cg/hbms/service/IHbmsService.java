package com.cg.hbms.service;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public interface IHbmsService {

	public User registerUser(User user) throws HbmsException;
	public User loginUser(User user) throws HbmsException;
	String isValidLogin(String username, String password);
	public String isValidRoom(RoomDetail room);
	public String isValidHotel(Hotel hotel);
	public String isValidBooking(BookingDetail bookingDetails);
	public String isValidUser(User user);
}
