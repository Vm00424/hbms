package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.dao.AdminDAOImpl;
import com.cg.hbms.dao.IAdminDAO;
import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public class AdminServiceImpl implements IAdminService {

	IAdminDAO admindao = new AdminDAOImpl();
	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		
		return admindao.getHotelList();
	}

	@Override
	public Hotel addHotel(Hotel hotel) throws HbmsException {
		return admindao.addHotel(hotel);
		
	}

	@Override
	public Boolean modifyHotel(Hotel hotel) throws HbmsException {

		return admindao.modifyHotel(hotel);
	}

	@Override
	public boolean deleteHotel(Integer hotelId) throws HbmsException {
		return admindao.deleteHotel(hotelId);
	}

	@Override
	public List<RoomDetail> getRoomList() throws HbmsException {
	
		return admindao.getRoomList();
	}

	@Override
	public RoomDetail addRoom(RoomDetail room) throws HbmsException {
		
		return admindao.addRoom(room);
	}

	@Override
	public Boolean modifyRoom(RoomDetail room) throws HbmsException {
		
		return admindao.modifyRoom(room);
		
	}

	@Override
	public boolean deleteRoom(Integer roomId) throws HbmsException {

		return admindao.deleteRoom(roomId);
	}

	@Override
	public List<BookingDetail> getBookingByHotel(Integer hotelId) throws HbmsException {
		
		return admindao.getBookingByHotel(hotelId);
	}

	@Override
	public List<User> getUserByHotel(Integer hotelId) throws HbmsException {
		
		return admindao.getUserByHotel(hotelId);
	}

	@Override
	public List<BookingDetail> getBookingByDate(String date) throws HbmsException {
		
		return admindao.getBookingByDate(date);
	}

}
