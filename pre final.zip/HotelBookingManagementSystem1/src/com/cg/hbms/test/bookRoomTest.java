package com.cg.hbms.test;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.IUserService;
import com.cg.hbms.service.UserServiceImpl;

public class bookRoomTest {
	BookingDetail bookingDetail;
	IUserService userService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		bookingDetail = new BookingDetail();
		userService = new UserServiceImpl();
		
		bookingDetail.setBookedFrom(new SimpleDateFormat("dd/MM/yyyy").parse("10/10/2018"));
		bookingDetail.setBookedTo(new SimpleDateFormat("dd/MM/yyyy").parse("15/10/2018"));
		bookingDetail.setRoomId(250);
		bookingDetail.setNoOfAdults(2);
		bookingDetail.setNoOfChildren(1);
		bookingDetail.setAmount(2500.0);
		bookingDetail.setUserId(1001);
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws HbmsException {
		bookingDetail = userService.bookRoom(bookingDetail);
		assertNotNull(bookingDetail.getBookingId());
	}

}
