package com.cg.hbms.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hbms.entities.Hotel;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.IAdminService;

public class modifyHotelTest {
	
	Hotel hotel;
	IAdminService adminService;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		hotel = new Hotel();
		adminService = new AdminServiceImpl();
		
		hotel.setHotelId(57);
		hotel.setCity("bangalore");
		hotel.setAddress("dtp");
		hotel.setAvgRatePerNight(2500.00);
		hotel.setDescription("near to capgemini dtp");
		hotel.setEmail("besys@hotel.com");
		hotel.setRating("3");
		hotel.setFax("778899423");
		hotel.setPhoneNoOne("9876543210");
		hotel.setPhoneNoTwo("8974561230");
		hotel.setHotelName("Best Stays");
		
		
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws HbmsException {
		
		assertTrue(adminService.modifyHotel(hotel));
		
	}
}