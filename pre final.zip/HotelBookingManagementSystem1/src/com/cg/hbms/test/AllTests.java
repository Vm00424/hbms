package com.cg.hbms.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ bookRoomTest.class, loginTest.class, modifyHotelTest.class })
public class AllTests {

}
