package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public interface IAdminDAO {
	
	// Hotel management
	public List<Hotel> getHotelList() throws HbmsException;
	public Hotel addHotel(Hotel hotel) throws HbmsException;
	public Boolean modifyHotel(Hotel hotel) throws HbmsException;
	public Boolean deleteHotel(Integer hotelId) throws HbmsException;
	
	
	// Room management
	public List<RoomDetail> getRoomList() throws HbmsException;//
	public RoomDetail addRoom(RoomDetail room) throws HbmsException;//
	public Boolean modifyRoom(RoomDetail room) throws HbmsException;
	public Boolean deleteRoom(Integer roomId) throws HbmsException;
	
	
	// Generating Reports
	public List<BookingDetail> getBookingByHotel(Integer hotelId) throws HbmsException;//
	public List<User> getUserByHotel(Integer hotelId) throws HbmsException;
	public List<BookingDetail> getBookingByDate(String date) throws HbmsException;
	
}
