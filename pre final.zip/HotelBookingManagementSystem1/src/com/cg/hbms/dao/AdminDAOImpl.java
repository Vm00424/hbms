package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.util.DbConnection;

public class AdminDAOImpl implements IAdminDAO {
	static Connection connection;
	static Logger logger;

	static {
		PropertyConfigurator.configure("src//log4j.properties");
		logger = Logger.getRootLogger();
	}

	
	
	
	
	
	
	
	
	

	@Override
	public List<RoomDetail> getRoomList() throws HbmsException {
		connection = DbConnection.getConnection();
		List<RoomDetail> roomList=new ArrayList<RoomDetail>();
		int roomCount=0;
		PreparedStatement preparedStatement=null;
		ResultSet resultset=null;
		try{
			preparedStatement = connection.prepareStatement(QueryMapper.GET_ROOM);
			resultset=preparedStatement.executeQuery();
			while(resultset.next()){
				RoomDetail roomdetail=new RoomDetail();
				roomdetail.setHotelId(resultset.getInt(1));
				roomdetail.setRoomId(resultset.getInt(2));
				roomdetail.setRoomNo(resultset.getString(3));
				roomdetail.setRoomType(resultset.getString(4));
				roomdetail.setPerNightRate(resultset.getDouble(5));
				roomdetail.setAvailability(resultset.getString(6));
				roomCount++;

				roomList.add(roomdetail);
			}
		}catch(SQLException sqlException){
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured.refer Log");
		}finally{
			try {
				if(resultset !=null){
					resultset.close();
				}
				if(preparedStatement !=null){
					preparedStatement.close();
				}
				if(connection !=null){
					connection.close();
				}


			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
		if(roomCount==0){
			return null;
		}else{
			return roomList;
		}


	}


	@Override
	public RoomDetail addRoom(RoomDetail room) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement2=null;
		ResultSet resultset = null;
		int queryResult = 0;
		Integer roomId = -1;

		try {
			preparedStatement=connection.prepareStatement(QueryMapper.ADD_ROOM);

			preparedStatement.setInt(1,room.getHotelId());
			preparedStatement.setString(2, room.getRoomNo());
			preparedStatement.setString(3,room.getRoomType());
			preparedStatement.setDouble(4, room.getPerNightRate());
			preparedStatement.setString(5, room.getAvailability());

			queryResult=preparedStatement.executeUpdate();

			
			if(queryResult==0){
				logger.error("insertion failed");
				throw new HbmsException("Inserting failed");
			}
			else{
				preparedStatement2=connection.prepareStatement(QueryMapper.GET_ROOM_CURR_SEQ);
				resultset=preparedStatement2.executeQuery();


				if(resultset.next()){
					roomId=resultset.getInt(1);
					room.setRoomId(roomId);
				}
				logger.info("successfully inserted");
				return room;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new HbmsException("technical problem.Refer to log for details");
		}
		finally{

			try {
				if(resultset != null){
					resultset.close();
				}
				if(preparedStatement != null){
					preparedStatement.close();
				}
				if(preparedStatement2!= null){
					preparedStatement.close();
				}
				if(connection != null){
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException("Error in closing the database connections");
			}
		}
	}


	@Override
	public List<Hotel> getHotelList() throws HbmsException {
		connection = DbConnection.getConnection();
		List<Hotel> hotelList=new ArrayList<Hotel>();
		int hotelCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.GET_HOTEL);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				Hotel hotel = new Hotel();
				hotel.setHotelId(resultSet.getInt(1));
				hotel.setCity(resultSet.getString(2));
				hotel.setHotelName(resultSet.getString(3));
				hotel.setAddress(resultSet.getString(4));
				hotel.setDescription(resultSet.getString(5));
				hotel.setAvgRatePerNight(resultSet.getDouble(6));
				hotel.setPhoneNoOne(resultSet.getString(7));
				hotel.setPhoneNoTwo(resultSet.getString(8));
				hotel.setRating(resultSet.getString(9));
				hotel.setEmail(resultSet.getString(10));
				hotel.setFax(resultSet.getString(11));
				hotelCount++;
				
				
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(hotelCount==0){
			return null;
		}else{
			return hotelList;
		}
	}


	@Override
	public Hotel addHotel(Hotel hotel) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement2=null;
		ResultSet resultset = null;
		int queryResult = 0;
		Integer hotelId = -1;

		try {
			preparedStatement=connection.prepareStatement(QueryMapper.ADD_HOTEL);

			preparedStatement.setString(1,hotel.getCity());
			preparedStatement.setString(2, hotel.getHotelName());
			preparedStatement.setString(3,hotel.getAddress());
			preparedStatement.setString(4,hotel.getDescription());
			preparedStatement.setDouble(5, hotel.getAvgRatePerNight());
			preparedStatement.setString(6, hotel.getPhoneNoOne());
			preparedStatement.setString(7, hotel.getPhoneNoTwo());
			preparedStatement.setString(8, hotel.getRating());
			preparedStatement.setString(9, hotel.getEmail());
			preparedStatement.setString(10, hotel.getFax());
			
			queryResult=preparedStatement.executeUpdate();

			preparedStatement2=connection.prepareStatement(QueryMapper.GET_HOTEL_CURR_SEQ);
			resultset=preparedStatement2.executeQuery();


			if(resultset.next()){
				hotelId=resultset.getInt(1);
				hotel.setHotelId(hotelId);
			}
			if(queryResult==0){
				logger.error("insertion failed");
				throw new HbmsException("Inserting failed");
			}
			else{
				logger.info("successfully inserted");
				return hotel;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new HbmsException("technical problem.Refer to log for details");
		}
		finally{

			try {
				if(resultset != null){
					resultset.close();
				}
				if(preparedStatement != null){
					preparedStatement.close();
				}
				if(preparedStatement2!= null){
					preparedStatement.close();
				}
				if(connection != null){
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException("Error in closing the database connections");
			}
		}
	
	}


	
	
	
	
	@Override
	public Boolean modifyHotel(Hotel hotel) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;
		
		Boolean result = false;
		int queryResult = 0;

		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.MODIFY_HOTEL);
			
			preparedStatement.setString(1, hotel.getCity());
			preparedStatement.setString(2, hotel.getHotelName());
			preparedStatement.setString(3, hotel.getAddress());
			preparedStatement.setString(4, hotel.getDescription());
			preparedStatement.setDouble(5, hotel.getAvgRatePerNight());
			preparedStatement.setString(6, hotel.getPhoneNoOne());
			preparedStatement.setString(7, hotel.getPhoneNoTwo());
			preparedStatement.setString(8, hotel.getRating());
			preparedStatement.setString(9, hotel.getEmail());
			preparedStatement.setString(10, hotel.getFax());
			preparedStatement.setInt(11, hotel.getHotelId());
			
			queryResult = preparedStatement.executeUpdate();
			if (queryResult == 0) {
				logger.error("modification failed");
				throw new HbmsException("modification failed");
			} else {
				result = true;
				logger.info("successfully modified");
				return result;
			}
		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new HbmsException("Error in modifying");
		} finally {

			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException(
						"Error in closing the database connections");

			}

		}
	}


	
	
	
	@Override
	public Boolean deleteHotel(Integer hotelId) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;

		int queryResult = 0;
		//Integer hotelId1 = -1;

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_HOTEL);
			preparedStatement.setInt(1, hotelId);
			queryResult = preparedStatement.executeUpdate();
			if (queryResult == 0) {
				logger.error("deletion failed");
				throw new HbmsException("deleting failed");
			} else {
				logger.info("successfully deleted");
				return true;
			}
		} catch (SQLException sqlException) {

			logger.error(sqlException.getMessage());
			throw new HbmsException("Error in deleting the hotel");
		} finally {

			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException(
						"Error in closing the database connections");
			}
		}
	}


	
	
	@Override
	public Boolean modifyRoom(RoomDetail room) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;
		
		Boolean result = false;
		int queryResult = 0;

		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.MODIFY_ROOM);
			preparedStatement.setInt(1, room.getHotelId());
			preparedStatement.setString(2, room.getRoomNo());
			preparedStatement.setString(3, room.getRoomType());
			preparedStatement.setDouble(4, room.getPerNightRate());
			preparedStatement.setString(5, room.getAvailability());
			preparedStatement.setInt(6, room.getRoomId());
			
			queryResult = preparedStatement.executeUpdate();
			if (queryResult == 0) {
				logger.error("modification failed");
				throw new HbmsException("modification failed");
			} else {
				result = true;
				logger.info("successfully modified");
				return result;
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Error in modifying");
		} finally {

			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException(
						"Error in closing the database connections");

			}

		}
	}

	
	

	@Override
	public Boolean deleteRoom(Integer roomId) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;

		int queryResult = 0;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_ROOM);
			preparedStatement.setInt(1, roomId);
			queryResult = preparedStatement.executeUpdate();
			
			if (queryResult == 0) {
				logger.error("deletion failed");
				throw new HbmsException("deleting failed");
			} else {
				logger.info("successfully deleted");
				return true;
			}
		} catch (SQLException sqlException) {

			logger.error(sqlException.getMessage());
			throw new HbmsException("Error in closing the database connections");
		} finally {

			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException(
						"Error in closing the database connections");
			}
		}
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public List<BookingDetail> getBookingByHotel(Integer hotelId) throws HbmsException {
		connection = DbConnection.getConnection();
		List<BookingDetail> bookingList=new ArrayList<BookingDetail>();
		int bookingCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.GET_BOOKING_BY_HOTEL);
			preparedStatement.setInt(1, hotelId);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				BookingDetail bookingDetails = new BookingDetail();
				bookingDetails.setBookingId(resultSet.getInt(1));
				bookingDetails.setRoomId(resultSet.getInt(2));
				bookingDetails.setUserId(resultSet.getInt(3));
				bookingDetails.setBookedFrom(resultSet.getDate(4));
				bookingDetails.setBookedTo(resultSet.getDate(5));
				bookingDetails.setNoOfAdults(resultSet.getInt(6));
				bookingDetails.setNoOfChildren(resultSet.getInt(7));
				bookingDetails.setAmount(resultSet.getDouble(8));
				bookingCount++;
				
				
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(bookingCount==0){
			return null;
		}else{
			return bookingList;
		}
	}


	@Override
	public List<User> getUserByHotel(Integer hotelId) throws HbmsException {
		connection = DbConnection.getConnection();
		List<User> userList=new ArrayList<User>();
		int userCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.GET_USER_BY_HOTEL);
			preparedStatement.setInt(1, hotelId);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				User users = new User();
				users.setUserId(resultSet.getInt(1));
				users.setPassword(resultSet.getString(2));
				users.setRole(resultSet.getString(3));
				users.setUserName(resultSet.getString(4));
				users.setMobileNumber(resultSet.getString(5));
				users.setPhoneNumber(resultSet.getString(6));
				users.setAddress(resultSet.getString(7));
				users.setEmail(resultSet.getString(8));
				userCount++;
				
				
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(userCount==0){
			return null;
		}else{
			return userList;
		}
		
	}


	@Override
	public List<BookingDetail> getBookingByDate(String date) throws HbmsException {
		connection = DbConnection.getConnection();
		List<BookingDetail> bookingList=new ArrayList<BookingDetail>();
		int bookingCount=0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.GET_BOOKING_BY_DATE);
			preparedStatement.setString(1, date);
			
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				BookingDetail bookingDetails = new BookingDetail();
				bookingDetails.setBookingId(resultSet.getInt(1));
				bookingDetails.setRoomId(resultSet.getInt(2));
				bookingDetails.setUserId(resultSet.getInt(3));
				bookingDetails.setBookedFrom(resultSet.getDate(4));
				bookingDetails.setBookedTo(resultSet.getDate(5));
				bookingDetails.setNoOfAdults(resultSet.getInt(6));
				bookingDetails.setNoOfChildren(resultSet.getInt(7));
				bookingDetails.setAmount(resultSet.getDouble(8));
				bookingCount++;
				
				
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new HbmsException("Technical problem occured. Refer Log....");

		}finally{
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				throw new HbmsException("Error !!! in closing DBConnection ....");
			}
			
		}
		if(bookingCount==0){
			return null;
		}else{
			return bookingList;
		}
	}
}
