DROP TABLE USER_master;
CREATE TABLE User_master(user_id VARCHAR2(4) PRIMARY KEY,
					password VARCHAR2(7),
					role VARCHAR2(10),
					user_name VARCHAR2(20),
					mobile_no VARCHAR2(10),
					phone VARCHAR2(10),
					address VARCHAR2(25),
					email VARCHAR2(25));
					
drop sequence user_seq;
CREATE SEQUENCE user_seq START WITH 1001 INCREMENT BY 1;

INSERT INTO USERS VALUES(user_seq.NEXTVAL,'admin','admin','admin','9878765456','1200535353','Bangalore','admin123@gmail.com');
INSERT INTO USERS VALUES(user_seq.NEXTVAL,'capgem','user','capgemini','9878765456','8765535353','Bangalore','cap123@gmail.com');

DROP TABLE HOTEL_master;
CREATE TABLE Hotel_master(hotel_id VARCHAR2(4) PRIMARY KEY,
					city VARCHAR2(10),
					hotel_name VARCHAR2(20),
					address VARCHAR2(25),
					description VARCHAR2(50),
					avg_rate_per_night NUMBER(10,2),
					phone_no1 VARCHAR2(10),
					phone_no2 VARCHAR2(10),
					rating VARCHAR2(4),
					email VARCHAR2(15),
					fax VARCHAR2(15));
					
select * from hotel;
drop sequence hotel_seq;					
CREATE SEQUENCE hotel_seq START WITH 1001 INCREMENT BY 1;

DROP TABLE ROOMDETAILS;
CREATE TABLE ROOMDETAILS(hotel_id VARCHAR2(4),
						 room_id VARCHAR2(4) PRIMARY KEY,
						 room_no VARCHAR2(3),
						 room_type VARCHAR2(20),
						 per_night_rate NUMBER(6,2),
						 availability VARCHAR2(20),
						 CONSTRAINT fk_hotel FOREIGN KEY(hotel_id) REFERENCES HOTEL(hotel_id)
						 ON DELETE CASCADE);
drop sequence room_seq;						 
CREATE SEQUENCE room_seq START WITH 1001 INCREMENT BY 1;

INSERT INTO ROOMDETAILS VALUES('1001',room_seq.nextval,'001','Standard AC','1000','AVAILABLE');
INSERT INTO ROOMDETAILS VALUES('1001',room_seq.nextval,'002','Deluxe AC','2000','AVAILABLE');
INSERT INTO ROOMDETAILS VALUES('1001',room_seq.nextval,'003','Deluxe AC','500','AVAILABLE');


drop sequence booking_detail_seq;							
CREATE SEQUENCE booking_detail_seq START WITH 1001 INCREMENT BY 1;

drop table booking_master;
create table booking_master(
booking_id number primary key,
booked_from date,
booked_to date,
no_of_adults number,
no_of_children number,
amount1 number,
amount2 number,
hotel_name varchar2(25))
;
SELECT * FROM ROOMDETAILS;

SELECT * FROM USERS;
DELETE FROM ROOMDETAILS;

DELETE FROM BOOKINGDETAILS;

SELECT * FROM BOOKINGDETAILS;

COMMIT;