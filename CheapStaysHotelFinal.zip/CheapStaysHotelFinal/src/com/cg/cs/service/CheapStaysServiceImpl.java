package com.cg.cs.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cs.dao.ICheapStaysDao;
import com.cg.cs.entities.BookingDetail;
import com.cg.cs.entities.Hotel;
import com.cg.cs.entities.RoomDetail;
import com.cg.cs.entities.User;
import com.cg.cs.exception.CheapStaysException;

@Service
@Transactional
public class CheapStaysServiceImpl implements ICheapStaysService {

	@Autowired
	ICheapStaysDao cheapStaysDao;

	public ICheapStaysDao getCheapStaysDao() {
		return cheapStaysDao;
	}

	public void setCheapStaysDao(ICheapStaysDao cheapStaysDao) {
		this.cheapStaysDao = cheapStaysDao;
	}

	@Override
	public User addUser(User user) throws CheapStaysException {

		return cheapStaysDao.addUser(user);
	}

	@Override
	public Hotel addHotel(Hotel hotel) throws CheapStaysException {

		return cheapStaysDao.addHotel(hotel);
	}

	@Override
	public void deleteHotel(Hotel hotel) throws CheapStaysException {

		cheapStaysDao.deleteHotel(hotel);
	}

	@Override
	public Hotel updateHotel(Hotel hotel) throws CheapStaysException {

		return cheapStaysDao.updateHotel(hotel);
	}

	@Override
	public Hotel getHotel(int hotelId) throws CheapStaysException {

		return cheapStaysDao.getHotel(hotelId);
	}

	@Override
	public List<Hotel> getAllHotels() throws CheapStaysException {

		return cheapStaysDao.getAllHotels();
	}

	@Override
	public boolean isValidUser(User user) throws CheapStaysException {

		return cheapStaysDao.isValidUser(user);
	}

	@Override
	public RoomDetail addRoom(RoomDetail room) throws CheapStaysException {
		return cheapStaysDao.addRoom(room);
	}

	@Override
	public List<RoomDetail> getAllRooms() throws CheapStaysException {
		return cheapStaysDao.getAllRooms();

	}

	@Override
	public RoomDetail getRoom(int roomId) throws CheapStaysException {
		return cheapStaysDao.getRoom(roomId);
	}

	@Override
	public RoomDetail updateRoom(RoomDetail room) throws CheapStaysException {
		return cheapStaysDao.updateRoom(room);
	}

	@Override
	public RoomDetail deleteRoom(int roomId) throws CheapStaysException {
		return cheapStaysDao.deleteRoom(roomId);

	}

	@Override
	public List<Hotel> getHotelByCity(String city) throws CheapStaysException {
		// TODO Auto-generated method stub
		return cheapStaysDao.getHotelByCity(city);
	}

	@Override
	public Map<String, Double> getPrice(int hotelId) throws CheapStaysException {
		// TODO Auto-generated method stub
		return cheapStaysDao.getPrice(hotelId);
	}

	@Override
	public BookingDetail bookRoom(BookingDetail bookingDetail)
			throws CheapStaysException {

		return cheapStaysDao.bookRoom(bookingDetail);
	}

	@Override
	public BookingDetail bookingStatus(int bookingId)
			throws CheapStaysException {
		// TODO Auto-generated method stub
		return cheapStaysDao.bookingStatus(bookingId);
	}

	@Override
	public List<RoomDetail> getAllRoomsById(int hotelId)
			throws CheapStaysException {
		return cheapStaysDao.getAllRoomsById(hotelId);
	}

	@Override
	public boolean isValidBookingFromDate(LocalDate fromDate)
			throws CheapStaysException {
		LocalDate date = LocalDate.now();
        return (!fromDate.isBefore(date));
	}
}
