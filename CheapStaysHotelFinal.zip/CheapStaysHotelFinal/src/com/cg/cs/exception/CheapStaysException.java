package com.cg.cs.exception;

@SuppressWarnings("serial")
public class CheapStaysException extends Exception {

	public CheapStaysException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
