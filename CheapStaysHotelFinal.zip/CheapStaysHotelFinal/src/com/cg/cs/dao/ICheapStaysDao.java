package com.cg.cs.dao;


import java.util.List;
import java.util.Map;

import com.cg.cs.entities.BookingDetail;
import com.cg.cs.entities.Hotel;
import com.cg.cs.entities.RoomDetail;
import com.cg.cs.entities.User;
import com.cg.cs.exception.CheapStaysException;

public interface ICheapStaysDao {

	public abstract User addUser(User user) throws CheapStaysException;
	public abstract boolean isValidUser(User user) throws CheapStaysException ;
	public abstract Hotel addHotel(Hotel hotel) throws CheapStaysException;
	public void deleteHotel(Hotel hotel) throws CheapStaysException;	
	public abstract Hotel getHotel(int hotelId) throws CheapStaysException;
	public Hotel updateHotel(Hotel hotel) throws CheapStaysException ;
	public abstract List<Hotel> getAllHotels() throws CheapStaysException;
	public abstract RoomDetail addRoom(RoomDetail room) throws CheapStaysException;
	public abstract List<RoomDetail> getAllRooms() throws CheapStaysException;
	public abstract RoomDetail getRoom(int roomId) throws CheapStaysException;
	public abstract RoomDetail updateRoom(RoomDetail room) throws CheapStaysException;
	public abstract RoomDetail deleteRoom(int roomId) throws CheapStaysException;
	public abstract List<Hotel> getHotelByCity(String city) throws CheapStaysException;
	public Map<String, Double> getPrice(int hotelId ) throws CheapStaysException;
	public BookingDetail bookRoom(BookingDetail bookingDetail)	throws CheapStaysException;
	public BookingDetail bookingStatus(int bookingId)	throws CheapStaysException;
	public abstract List<RoomDetail> getAllRoomsById(int hotelId) throws CheapStaysException;
	
}
