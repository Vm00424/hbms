package com.cg.hbms.client;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IHbmsService;

public class HbmsMain {

	public static void main(String[] args) throws HbmsException {
		
		IHbmsService hbmsService = new HbmsServiceImpl();
		
		User user = new User();
		user.setUserName("anup");
		user.setPassword("raaj");
		user.setRole("employee");
		user.setMobileNumber("897896878");
		user.setPhoneNumber("2323-22-1");
		user.setAddress("dawath");
		user.setEmail("anup@sfk.com");
		
		hbmsService.registerUser(user);
		System.out.println(user.getUserName());

	}

}
