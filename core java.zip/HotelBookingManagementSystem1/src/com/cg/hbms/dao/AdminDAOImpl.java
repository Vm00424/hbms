package com.cg.hbms.dao;

public class AdminDAOImpl {

}
