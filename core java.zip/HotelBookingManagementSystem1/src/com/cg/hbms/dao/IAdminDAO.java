package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.exception.HbmsException;

public interface IAdminDAO {
	
	public List<Hotel> getHotel() throws HbmsException;
	public List<BookingDetail> getBookingByHotel() throws HbmsException;
	
}
