package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.exception.HbmsException;

public class UserDAOImpl implements IUserDAO {

	@Override
	public List<Hotel> getHotel() throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RoomDetail> getRoomByHotel(Integer hotelId)
			throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingDetail bookRoom(BookingDetail bookingDetail)
			throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookingDetail> getBookingByUser(Integer userId)
			throws HbmsException {
		// TODO Auto-generated method stub
		return null;
	}

}
