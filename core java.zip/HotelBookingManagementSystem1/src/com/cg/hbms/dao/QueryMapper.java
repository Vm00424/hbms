package com.cg.hbms.dao;

public class QueryMapper {

	public static final String REGISTER_USER = "INSERT INTO users VALUES(users_seq.nextVal,?,?,?,?,?,?,?)";
	public static final String LOG_IN = "SELECT * FROM users WHERE user_name = ? AND password = ?";
	
	
	
	// report generating queries
	
	public static final String GET_HOTEL = "SELECT * FROM hotel";
	public static final String GET_BOOKING_BY_HOTEL = "SELECT * FROM bookingDetails WHERE room_id IN (SELECT room_id FROM roomDetails WHERE hotel_id = ?)";
	public static final String GET_BOOKING_BY_DATE = "SELECT * FROM bookingDetails WHERE ? BEETWEEN booked_from AND booked_to";
	public static final String GET_USER_BY_HOTEL = "SELECT * FROM users WHERE user_id IN "
			+ "(SELECT user_id FROM bookingDetails WHERE room_id IN (SELECT room_id FROM roomDetails WHERE hotel_id = ?))";
	
	
	
	// USER function queries
	
	public static final String GET_BOOKING_BY_USER = "SELECT * FROM bookingDetails WHERE user_id = ?";
	public static final String GET_ROOM_BY_HOTEL = "SELECT * FROM roomDetails WHERE hotel_id = ?";
	public static final String BOOK_ROOM = "INSERT INTO roomDetails VALUES(?,?,?,?,?,?)";
	
	
}
